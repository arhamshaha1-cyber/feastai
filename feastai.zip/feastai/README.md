# FeastAI - AI-Powered Food Assistant

Turn any ingredients into delicious recipes using AI.

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Set up environment variables
cp .env.example .env
# Edit .env with your API keys

# 3. Run development server
npm run dev
# Open http://localhost:3000
```

## Get Your API Keys

### Anthropic (for AI recipes)
1. Go to https://console.anthropic.com
2. Create an API key
3. Add to .env as VITE_ANTHROPIC_API_KEY

### Firebase (for login/database)
1. Go to https://console.firebase.google.com
2. Create a project
3. Enable Authentication (Email/Password)
4. Go to Project Settings > Your Apps > Web
5. Copy the config values into .env

## Deploy to Vercel (Free)
1. Push this folder to GitHub
2. Go to https://vercel.com and import your repo
3. Add your .env keys as Environment Variables in Vercel
4. Click Deploy

## Project Structure

```
feastai/
├── index.html
├── package.json
├── vite.config.js
├── vercel.json
├── .env.example
├── public/
│   └── logo.svg
├── api/
│   └── generate-recipes.js
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── components/
    │   ├── Logo.jsx
    │   ├── Nav.jsx
    │   ├── Footer.jsx
    │   └── RecipeCard.jsx
    ├── pages/
    │   ├── LandingPage.jsx
    │   ├── AppPage.jsx
    │   ├── AuthPage.jsx
    │   ├── PricingPage.jsx
    │   ├── FeaturesPage.jsx
    │   ├── AboutPage.jsx
    │   ├── TermsPage.jsx
    │   └── PrivacyPage.jsx
    ├── hooks/
    │   └── useAuth.js
    ├── lib/
    │   ├── firebase.js
    │   └── anthropic.js
    └── styles/
        ├── globals.css
        └── theme.js
```
