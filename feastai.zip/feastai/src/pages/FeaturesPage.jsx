import { useNavigate } from 'react-router-dom'
import { primaryBtn } from '../styles/theme'

const FEATURES = [
  { icon: '🤖', title: 'Claude AI Recipe Engine', color: '#FF6B35', desc: "Powered by Anthropic's Claude — one of the most advanced AI models available. It understands cultural nuances, regional flavor profiles, ingredient substitutions, and cooking techniques across all major world cuisines." },
  { icon: '🌍', title: '5 Authentic Global Cuisines', color: '#34D399', desc: 'Indian (curries, biryanis, dals), American (BBQ, comfort food), Arabic (mezze, tagines, shawarma), Chinese (stir-fries, noodles, dim sum), and Healthy (macro-balanced, clean eating). Authentic, not watered-down.' },
  { icon: '💰', title: 'Under $5 Budget Mode', color: '#F59E0B', desc: 'One tap activates budget intelligence. The AI reprioritizes from your exact ingredients to find the cheapest, most filling meals possible. Designed for students, budget families, and end-of-month cooking.' },
  { icon: '📊', title: 'Full Nutrition Breakdown', color: '#4FC3F7', desc: 'Every recipe includes estimated calories, protein, carbohydrates, and fat per serving. Track macros without a separate app.' },
  { icon: '⚡', title: 'Results in Under 10 Seconds', color: '#A78BFA', desc: '3 complete recipes with ingredient lists, step-by-step instructions, full nutrition panels, and chef tips — delivered in under 10 seconds.' },
  { icon: '📱', title: 'Mobile-First Design', color: '#F472B6', desc: 'Every button, font, and layout is optimized for one-handed phone use in the kitchen. Works on iOS and Android browsers without any app download.' },
  { icon: '🔒', title: 'Privacy First Always', color: '#34D399', desc: 'Zero advertising. Zero data selling. We are 100% subscription-funded. Your ingredient inputs and dietary preferences are yours alone.' },
  { icon: '👨‍👩‍👧‍👦', title: 'Family Plans', color: '#FF6B35', desc: 'Up to 5 individual profiles with separate dietary preferences. Generate a weekly meal plan, auto-create shopping lists, and scale portion sizes automatically.' },
]

export default function FeaturesPage() {
  const navigate = useNavigate()

  return (
    <div style={{ minHeight: '100vh', paddingTop: 100, padding: '100px 24px 72px' }}>
      <div style={{ textAlign: 'center', marginBottom: 64 }}>
        <h1 style={{
          fontFamily: "'Playfair Display', serif",
          fontSize: 'clamp(32px, 5vw, 54px)',
          fontWeight: 800,
          marginBottom: 16,
        }}>
          Every Feature Designed Around<br />How People Actually Cook
        </h1>
        <p style={{ color: '#9CA3AF', fontSize: 18, maxWidth: 540, margin: '0 auto' }}>
          With what they have, on a budget, with limited time, for real families.
        </p>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
        gap: 18,
        maxWidth: 1100,
        margin: '0 auto',
      }}>
        {FEATURES.map((f, i) => (
          <div key={i} style={{
            background: 'rgba(255,255,255,0.04)',
            border: '1px solid rgba(255,255,255,0.08)',
            borderRadius: 18,
            padding: 28,
            display: 'flex',
            gap: 18,
          }}>
            <div style={{
              fontSize: 28,
              width: 56,
              height: 56,
              borderRadius: 14,
              flexShrink: 0,
              background: f.color + '18',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
              {f.icon}
            </div>
            <div>
              <h3 style={{ color: '#F9FAFB', fontSize: 16, fontWeight: 700, marginBottom: 8 }}>{f.title}</h3>
              <p style={{ color: '#9CA3AF', fontSize: 14, lineHeight: 1.7, margin: 0 }}>{f.desc}</p>
            </div>
          </div>
        ))}
      </div>

      <div style={{ textAlign: 'center', marginTop: 60 }}>
        <button
          onClick={() => navigate('/signup')}
          style={primaryBtn({ padding: '16px 44px', fontSize: 17, borderRadius: 14 })}
        >
          🚀 Try Every Feature Free
        </button>
      </div>
    </div>
  )
}
