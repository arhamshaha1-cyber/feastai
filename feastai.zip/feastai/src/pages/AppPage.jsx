import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { generateRecipes } from '../lib/anthropic'
import { RecipeCard, RecipeDetail } from '../components/RecipeCard'
import { CUISINES, SAMPLE_INGREDIENTS, primaryBtn, ghostBtn } from '../styles/theme'

export default function AppPage({ user }) {
  const navigate = useNavigate()
  const [ingredients, setIngredients]       = useState([])
  const [inputVal, setInputVal]             = useState('')
  const [selectedCuisine, setSelectedCuisine] = useState('indian')
  const [budgetMode, setBudgetMode]         = useState(false)
  const [recipes, setRecipes]               = useState([])
  const [loading, setLoading]               = useState(false)
  const [error, setError]                   = useState('')
  const [selectedRecipe, setSelectedRecipe] = useState(null)

  function addIngredient(item) {
    const val = (item || inputVal).trim().toLowerCase()
    if (val && !ingredients.includes(val) && ingredients.length < 15) {
      setIngredients(prev => [...prev, val])
      setInputVal('')
    }
  }

  function removeIngredient(item) {
    setIngredients(prev => prev.filter(i => i !== item))
  }

  async function handleGenerate() {
    if (ingredients.length < 2) {
      setError('Please add at least 2 ingredients.')
      return
    }
    setLoading(true)
    setError('')
    setRecipes([])
    setSelectedRecipe(null)

    const cuisine = CUISINES.find(c => c.id === selectedCuisine)?.label || selectedCuisine

    try {
      const results = await generateRecipes(ingredients, cuisine, budgetMode)
      setRecipes(results)
    } catch (err) {
      if (err.message === 'MISSING_API_KEY') {
        setError('Add your VITE_ANTHROPIC_API_KEY to .env to enable AI recipes. See README.md for setup instructions.')
      } else {
        setError('AI request failed: ' + err.message + '. Please try again.')
      }
    }

    setLoading(false)
  }

  function toggleRecipe(r) {
    setSelectedRecipe(prev => prev?.name === r.name ? null : r)
  }

  const suggestions = SAMPLE_INGREDIENTS.filter(i => !ingredients.includes(i)).slice(0, 12)

  return (
    <div style={{
      minHeight: '100vh',
      paddingTop: 80,
      padding: '88px 20px 48px',
      maxWidth: 1100,
      margin: '0 auto',
    }}>
      <div style={{ marginBottom: 32 }}>
        <h1 style={{
          fontFamily: "'Playfair Display', serif",
          fontSize: 'clamp(26px, 5vw, 40px)',
          fontWeight: 700,
          marginBottom: 8,
        }}>
          {user ? 'Welcome back, ' + user.name + '! 👋' : "What's in your kitchen? 🧑‍🍳"}
        </h1>
        <p style={{ color: '#9CA3AF', fontSize: 16 }}>
          Add your ingredients and let AI create something delicious.
          {!user && (
            <span>
              {' '}
              <span
                onClick={() => navigate('/signup')}
                style={{ color: '#FF6B35', cursor: 'pointer', fontWeight: 600 }}
              >
                Sign up
              </span>{' '}
              to save your recipes.
            </span>
          )}
        </p>
      </div>

      {/* INPUT PANEL */}
      <div style={{
        background: 'rgba(255,255,255,0.04)',
        border: '1px solid rgba(255,255,255,0.08)',
        borderRadius: 24,
        padding: 28,
        marginBottom: 28,
      }}>

        {/* Cuisine selector */}
        <div style={{ marginBottom: 24 }}>
          <label style={{
            display: 'block',
            color: '#9CA3AF',
            fontSize: 12,
            fontWeight: 700,
            letterSpacing: 1.2,
            textTransform: 'uppercase',
            marginBottom: 12,
          }}>
            🌍 Select Cuisine
          </label>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {CUISINES.map(c => (
              <button
                key={c.id}
                onClick={() => setSelectedCuisine(c.id)}
                style={{
                  padding: '9px 18px',
                  borderRadius: 999,
                  fontSize: 14,
                  fontWeight: 600,
                  cursor: 'pointer',
                  fontFamily: "'DM Sans', sans-serif",
                  background: selectedCuisine === c.id ? c.color : 'rgba(255,255,255,0.06)',
                  color: selectedCuisine === c.id ? '#fff' : '#9CA3AF',
                  border: selectedCuisine === c.id ? '2px solid ' + c.color : '2px solid transparent',
                  boxShadow: selectedCuisine === c.id ? '0 4px 16px ' + c.color + '44' : 'none',
                }}
              >
                {c.label}
              </button>
            ))}
          </div>
        </div>

        {/* Budget toggle */}
        <div
          onClick={() => setBudgetMode(p => !p)}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 14,
            marginBottom: 24,
            padding: '14px 18px',
            borderRadius: 12,
            background: budgetMode ? 'rgba(52,211,153,0.08)' : 'rgba(255,255,255,0.03)',
            border: budgetMode ? '1px solid rgba(52,211,153,0.3)' : '1px solid rgba(255,255,255,0.08)',
            cursor: 'pointer',
          }}
        >
          <div style={{
            width: 46,
            height: 26,
            borderRadius: 13,
            background: budgetMode ? '#34D399' : '#374151',
            position: 'relative',
            transition: 'background 0.25s',
            flexShrink: 0,
          }}>
            <div style={{
              width: 20,
              height: 20,
              borderRadius: '50%',
              background: '#fff',
              position: 'absolute',
              top: 3,
              left: budgetMode ? 23 : 3,
              transition: 'left 0.25s',
            }} />
          </div>
          <div>
            <div style={{ color: budgetMode ? '#34D399' : '#F9FAFB', fontWeight: 600, fontSize: 15 }}>
              💰 Cheap Meals Under $5 Mode
            </div>
            <div style={{ color: '#6B7280', fontSize: 13, marginTop: 2 }}>
              AI will prioritize budget-friendly recipes
            </div>
          </div>
        </div>

        {/* Ingredient input */}
        <div style={{ marginBottom: 24 }}>
          <label style={{
            display: 'block',
            color: '#9CA3AF',
            fontSize: 12,
            fontWeight: 700,
            letterSpacing: 1.2,
            textTransform: 'uppercase',
            marginBottom: 12,
          }}>
            🛒 Your Ingredients ({ingredients.length}/15)
          </label>

          <div style={{ display: 'flex', gap: 10, marginBottom: 14 }}>
            <input
              value={inputVal}
              onChange={e => setInputVal(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && addIngredient()}
              placeholder="Type an ingredient and press Enter..."
              style={{
                flex: 1,
                padding: '12px 16px',
                background: 'rgba(255,255,255,0.06)',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: 12,
                color: '#F9FAFB',
                fontSize: 15,
                outline: 'none',
                fontFamily: "'DM Sans', sans-serif",
              }}
            />
            <button
              onClick={() => addIngredient()}
              style={primaryBtn({ padding: '12px 22px', borderRadius: 12, fontSize: 22 })}
            >
              +
            </button>
          </div>

          {/* Quick add */}
          <div style={{ marginBottom: 16 }}>
            <p style={{ color: '#6B7280', fontSize: 12, marginBottom: 8 }}>Quick add:</p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              {suggestions.map(s => (
                <button
                  key={s}
                  onClick={() => addIngredient(s)}
                  style={{
                    padding: '5px 12px',
                    fontSize: 12,
                    borderRadius: 999,
                    background: 'rgba(255,255,255,0.05)',
                    border: '1px solid rgba(255,255,255,0.1)',
                    color: '#9CA3AF',
                    cursor: 'pointer',
                    fontFamily: "'DM Sans', sans-serif",
                  }}
                >
                  + {s}
                </button>
              ))}
            </div>
          </div>

          {/* Ingredient tags */}
          {ingredients.length > 0 && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {ingredients.map(item => (
                <div key={item} style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  background: 'rgba(255,107,53,0.15)',
                  border: '1px solid rgba(255,107,53,0.3)',
                  borderRadius: 999,
                  padding: '6px 14px',
                }}>
                  <span style={{ color: '#FF9A5C', fontSize: 14, fontWeight: 500 }}>{item}</span>
                  <span
                    onClick={() => removeIngredient(item)}
                    style={{ color: '#FF6B35', cursor: 'pointer', fontSize: 18, lineHeight: 1 }}
                  >
                    ×
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {error && (
          <div style={{
            background: 'rgba(239,68,68,0.1)',
            border: '1px solid rgba(239,68,68,0.3)',
            borderRadius: 10,
            padding: '12px 16px',
            marginBottom: 18,
            color: '#FCA5A5',
            fontSize: 14,
            lineHeight: 1.5,
          }}>
            {error}
          </div>
        )}

        <button
          onClick={handleGenerate}
          disabled={loading}
          style={primaryBtn({
            width: '100%',
            padding: '16px',
            fontSize: 17,
            borderRadius: 12,
            boxShadow: loading ? 'none' : '0 6px 24px rgba(255,107,53,0.4)',
          })}
        >
          {loading ? '🤖 AI is crafting your recipes...' : '✨ Generate AI Recipes'}
        </button>
      </div>

      {/* LOADING */}
      {loading && (
        <div style={{ textAlign: 'center', padding: '60px 20px' }}>
          <div style={{ fontSize: 52, marginBottom: 16, display: 'inline-block', animation: 'spin 1s linear infinite' }}>
            🍳
          </div>
          <p style={{ color: '#9CA3AF', fontSize: 17 }}>Our AI chef is working on your recipes...</p>
          <p style={{ color: '#6B7280', fontSize: 14, marginTop: 8 }}>Usually takes 5–10 seconds</p>
        </div>
      )}

      {/* RESULTS */}
      {recipes.length > 0 && !loading && (
        <div>
          <h2 style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: 28,
            fontWeight: 700,
            marginBottom: 20,
          }}>
            🍽️ Your AI-Generated Recipes
          </h2>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
            gap: 18,
          }}>
            {recipes.map((r, i) => (
              <RecipeCard
                key={i}
                recipe={r}
                onClick={() => toggleRecipe(r)}
                selected={selectedRecipe?.name === r.name}
              />
            ))}
          </div>

          {selectedRecipe && (
            <RecipeDetail recipe={selectedRecipe} onClose={() => setSelectedRecipe(null)} />
          )}

          <div style={{ textAlign: 'center', marginTop: 28 }}>
            <button onClick={handleGenerate} style={ghostBtn({ padding: '12px 28px', fontSize: 15 })}>
              🔄 Generate Different Recipes
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
