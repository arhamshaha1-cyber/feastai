import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Logo from '../components/Logo'
import { useAuth } from '../hooks/useAuth'
import { primaryBtn } from '../styles/theme'

export default function AuthPage({ mode }) {
  const navigate = useNavigate()
  const { login, signup, error, setError } = useAuth()
  const [name, setName]         = useState('')
  const [email, setEmail]       = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading]   = useState(false)

  const isSignup = mode === 'signup'

  async function handleSubmit() {
    if (!email || !password) { setError('Please fill in all fields.'); return }
    if (isSignup && !name)   { setError('Please enter your name.'); return }
    if (password.length < 6) { setError('Password must be at least 6 characters.'); return }
    setLoading(true)
    const ok = isSignup
      ? await signup(name, email, password)
      : await login(email, password)
    setLoading(false)
    if (ok) navigate('/app')
  }

  function handleKey(e) {
    if (e.key === 'Enter') handleSubmit()
  }

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '80px 24px 40px',
      background: 'radial-gradient(ellipse 60% 50% at 50% 20%, rgba(255,107,53,0.09) 0%, transparent 70%)',
    }}>
      <div style={{
        width: '100%',
        maxWidth: 440,
        background: 'rgba(255,255,255,0.04)',
        border: '1px solid rgba(255,255,255,0.1)',
        borderRadius: 24,
        padding: '40px 36px',
        boxShadow: '0 25px 80px rgba(0,0,0,0.5)',
      }}>
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div onClick={() => navigate('/')} style={{ cursor: 'pointer', display: 'inline-block' }}>
            <Logo size={40} />
          </div>
          <h2 style={{
            marginTop: 20,
            fontFamily: "'Playfair Display', serif",
            fontSize: 26,
            color: '#F9FAFB',
            fontWeight: 700,
          }}>
            {isSignup ? 'Create Your Account' : 'Welcome Back'}
          </h2>
          <p style={{ color: '#6B7280', fontSize: 14, marginTop: 8 }}>
            {isSignup ? 'Free forever — no credit card needed' : 'Sign in to your FeastAI account'}
          </p>
        </div>

        {error && (
          <div style={{
            background: 'rgba(239,68,68,0.1)',
            border: '1px solid rgba(239,68,68,0.3)',
            borderRadius: 10,
            padding: '10px 14px',
            marginBottom: 20,
            color: '#FCA5A5',
            fontSize: 14,
          }}>
            {error}
          </div>
        )}

        {isSignup && (
          <Field label="Full Name" placeholder="Gordon Ramsay" value={name}
            onChange={e => { setError(''); setName(e.target.value) }} onKeyDown={handleKey} icon="👤" />
        )}
        <Field label="Email Address" type="email" placeholder="you@example.com" value={email}
          onChange={e => { setError(''); setEmail(e.target.value) }} onKeyDown={handleKey} icon="📧" />
        <Field label="Password" type="password" placeholder="Min 6 characters" value={password}
          onChange={e => { setError(''); setPassword(e.target.value) }} onKeyDown={handleKey} icon="🔑" />

        <button
          onClick={handleSubmit}
          disabled={loading}
          style={primaryBtn({ width: '100%', padding: '14px', fontSize: 16, borderRadius: 12, marginTop: 6 })}
        >
          {loading ? '⏳ Please wait...' : isSignup ? '🚀 Create Account' : '🔓 Sign In'}
        </button>

        <div style={{ textAlign: 'center', marginTop: 22, color: '#6B7280', fontSize: 14 }}>
          {isSignup ? (
            <>Already have an account?{' '}
              <span onClick={() => navigate('/login')} style={{ color: '#FF6B35', cursor: 'pointer', fontWeight: 600 }}>
                Sign In
              </span>
            </>
          ) : (
            <>Don't have an account?{' '}
              <span onClick={() => navigate('/signup')} style={{ color: '#FF6B35', cursor: 'pointer', fontWeight: 600 }}>
                Sign Up Free
              </span>
            </>
          )}
        </div>

        <div style={{
          marginTop: 24,
          padding: '12px 14px',
          background: 'rgba(255,107,53,0.05)',
          borderRadius: 10,
          border: '1px solid rgba(255,107,53,0.12)',
        }}>
          <p style={{ color: '#9CA3AF', fontSize: 12, textAlign: 'center', margin: 0, lineHeight: 1.6 }}>
            🔒 Firebase Auth powered · Demo mode until you add Firebase config to .env
          </p>
        </div>
      </div>
    </div>
  )
}

function Field({ label, type = 'text', placeholder, value, onChange, onKeyDown, icon }) {
  const [focused, setFocused] = useState(false)
  return (
    <div style={{ marginBottom: 18 }}>
      <label style={{ display: 'block', color: '#9CA3AF', fontSize: 13, fontWeight: 600, marginBottom: 8 }}>
        {label}
      </label>
      <div style={{ position: 'relative' }}>
        <span style={{
          position: 'absolute', left: 14, top: '50%',
          transform: 'translateY(-50%)', fontSize: 16, pointerEvents: 'none',
        }}>
          {icon}
        </span>
        <input
          type={type}
          value={value}
          onChange={onChange}
          onKeyDown={onKeyDown}
          placeholder={placeholder}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={{
            width: '100%',
            padding: '12px 14px 12px 42px',
            background: 'rgba(255,255,255,0.06)',
            border: focused ? '1px solid rgba(255,107,53,0.5)' : '1px solid rgba(255,255,255,0.1)',
            borderRadius: 12,
            color: '#F9FAFB',
            fontSize: 15,
            outline: 'none',
            boxSizing: 'border-box',
            fontFamily: "'DM Sans', sans-serif",
          }}
        />
      </div>
    </div>
  )
}
