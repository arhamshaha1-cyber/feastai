import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { primaryBtn, ghostBtn } from '../styles/theme'

const FEATURES = [
  { icon: '🤖', title: 'Claude AI Recipe Engine', desc: "Powered by Anthropic's Claude. Understands cultural nuances, dietary needs, and cooking techniques across all major world cuisines." },
  { icon: '🌍', title: '5 Global Cuisines', desc: 'Indian, American, Arabic, Chinese and Healthy diets — authentic, culturally accurate recipes every time.' },
  { icon: '💰', title: 'Meals Under $5', desc: 'Budget mode reprioritizes AI suggestions to find the cheapest, most filling meals from your pantry staples.' },
  { icon: '📊', title: 'Full Nutrition Data', desc: 'Every recipe includes calorie, protein, carb and fat estimates so you can track macros without a separate app.' },
  { icon: '⚡', title: 'Results in 10 Seconds', desc: 'Three complete recipes with ingredients, steps, nutrition and chef tips delivered in under 10 seconds.' },
  { icon: '🔒', title: 'Private and Ad-Free', desc: 'We are subscription-funded. Your data is never sold. Zero tracking pixels. Zero ads.' },
]

export default function LandingPage() {
  const navigate = useNavigate()
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 80)
    return () => clearTimeout(t)
  }, [])

  return (
    <div>
      {/* HERO */}
      <section style={{
        minHeight: '92vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center',
        padding: '100px 24px 80px',
        background: 'radial-gradient(ellipse 80% 55% at 50% 0%, rgba(255,107,53,0.11) 0%, transparent 70%)',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: 8,
          background: 'rgba(255,107,53,0.1)',
          border: '1px solid rgba(255,107,53,0.25)',
          borderRadius: 999,
          padding: '6px 18px',
          marginBottom: 30,
          opacity: visible ? 1 : 0,
          transform: visible ? 'translateY(0)' : 'translateY(20px)',
          transition: 'all 0.6s ease',
        }}>
          <span style={{ fontSize: 12, color: '#FF6B35', fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase' }}>
            ✨ AI-Powered Food Intelligence
          </span>
        </div>

        <h1 style={{
          fontFamily: "'Playfair Display', Georgia, serif",
          fontSize: 'clamp(40px, 9vw, 92px)',
          fontWeight: 900,
          lineHeight: 1.02,
          marginBottom: 26,
          maxWidth: 950,
          opacity: visible ? 1 : 0,
          transform: visible ? 'translateY(0)' : 'translateY(28px)',
          transition: 'all 0.65s ease 0.1s',
        }}>
          <span style={{ color: '#F9FAFB' }}>Turn Any Ingredients</span>
          <br />
          <span style={{
            background: 'linear-gradient(135deg, #FF6B35 0%, #FFB347 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
          }}>
            Into Masterpieces
          </span>
        </h1>

        <p style={{
          fontSize: 'clamp(16px, 2.5vw, 20px)',
          color: '#9CA3AF',
          maxWidth: 580,
          lineHeight: 1.7,
          marginBottom: 42,
          opacity: visible ? 1 : 0,
          transform: visible ? 'translateY(0)' : 'translateY(28px)',
          transition: 'all 0.65s ease 0.2s',
        }}>
          FeastAI uses Claude AI to suggest delicious, culturally diverse recipes from ingredients you already have — with full nutrition data and budget options.
        </p>

        <div style={{
          display: 'flex',
          gap: 14,
          flexWrap: 'wrap',
          justifyContent: 'center',
          opacity: visible ? 1 : 0,
          transition: 'all 0.65s ease 0.3s',
        }}>
          <button
            onClick={() => navigate('/signup')}
            style={primaryBtn({ padding: '16px 36px', fontSize: 17, borderRadius: 14, boxShadow: '0 8px 30px rgba(255,107,53,0.42)' })}
          >
            🚀 Start Cooking Free
          </button>
          <button
            onClick={() => navigate('/app')}
            style={ghostBtn({ padding: '16px 36px', fontSize: 17, borderRadius: 14 })}
          >
            Try Without Signup →
          </button>
        </div>

        <div style={{
          marginTop: 64,
          display: 'flex',
          gap: 48,
          flexWrap: 'wrap',
          justifyContent: 'center',
          opacity: visible ? 1 : 0,
          transition: 'all 0.65s ease 0.45s',
        }}>
          {[['50K+', 'Recipes Generated'], ['5', 'Global Cuisines'], ['4.9★', 'User Rating']].map(([num, label]) => (
            <div key={label} style={{ textAlign: 'center' }}>
              <div style={{
                fontSize: 30,
                fontWeight: 800,
                fontFamily: "'Playfair Display', serif",
                background: 'linear-gradient(135deg, #FF6B35, #FFB347)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}>
                {num}
              </div>
              <div style={{ fontSize: 13, color: '#6B7280', marginTop: 4 }}>{label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURES */}
      <section style={{ padding: '80px 24px', maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 56 }}>
          <h2 style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: 'clamp(28px, 5vw, 50px)',
            fontWeight: 700,
            marginBottom: 16,
          }}>
            Everything You Need to Cook Smarter
          </h2>
          <p style={{ color: '#9CA3AF', fontSize: 18, maxWidth: 480, margin: '0 auto' }}>
            No more staring at the fridge wondering what to make.
          </p>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
          gap: 18,
        }}>
          {FEATURES.map((f, i) => (
            <div key={i} style={{
              background: 'rgba(255,255,255,0.04)',
              border: '1px solid rgba(255,255,255,0.08)',
              borderRadius: 18,
              padding: 28,
            }}>
              <div style={{ fontSize: 38, marginBottom: 14 }}>{f.icon}</div>
              <h3 style={{ color: '#F9FAFB', fontSize: 17, fontWeight: 700, marginBottom: 10 }}>{f.title}</h3>
              <p style={{ color: '#9CA3AF', fontSize: 14, lineHeight: 1.7, margin: 0 }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA BANNER */}
      <section style={{
        margin: '0 24px 80px',
        borderRadius: 24,
        padding: '64px 40px',
        textAlign: 'center',
        maxWidth: 900,
        marginLeft: 'auto',
        marginRight: 'auto',
        background: 'linear-gradient(135deg, rgba(255,107,53,0.13) 0%, rgba(167,139,250,0.09) 100%)',
        border: '1px solid rgba(255,107,53,0.2)',
      }}>
        <h2 style={{
          fontFamily: "'Playfair Display', serif",
          fontSize: 'clamp(26px, 4vw, 42px)',
          color: '#F9FAFB',
          marginBottom: 16,
          fontWeight: 700,
        }}>
          Ready to Never Wonder "What's for Dinner?" Again?
        </h2>
        <p style={{ color: '#9CA3AF', fontSize: 17, marginBottom: 36 }}>
          Join thousands of home cooks using AI to eat better, spend less, and stress less.
        </p>
        <button
          onClick={() => navigate('/signup')}
          style={primaryBtn({ padding: '16px 44px', fontSize: 18, borderRadius: 14 })}
        >
          Get Started — It's Free
        </button>
      </section>
    </div>
  )
}
