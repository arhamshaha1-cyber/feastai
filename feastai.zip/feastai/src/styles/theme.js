export const CUISINES = [
  { id: 'indian',   label: '🇮🇳 Indian',   color: '#FF6B35' },
  { id: 'american', label: '🇺🇸 American', color: '#4FC3F7' },
  { id: 'arabic',   label: '🌙 Arabic',    color: '#A78BFA' },
  { id: 'chinese',  label: '🐉 Chinese',   color: '#F59E0B' },
  { id: 'healthy',  label: '🥗 Healthy',   color: '#34D399' },
]

export const SAMPLE_INGREDIENTS = [
  'chicken', 'rice', 'tomatoes', 'onions', 'garlic', 'olive oil',
  'eggs', 'pasta', 'lentils', 'spinach', 'potatoes', 'cheese',
  'bread', 'milk', 'butter', 'flour', 'beans', 'peppers',
  'ginger', 'cumin', 'soy sauce', 'coconut milk', 'chickpeas',
  'mushrooms', 'broccoli', 'carrots', 'tofu',
]

export const PRICING_PLANS = [
  {
    name: 'Free',
    price: '$0',
    period: 'forever',
    color: '#6B7280',
    features: [
      '5 AI recipe suggestions per day',
      'Basic calorie estimates',
      '2 cuisine types',
      'Community support',
    ],
    cta: 'Get Started Free',
    highlight: false,
  },
  {
    name: 'Chef',
    price: '$7.99',
    period: '/month',
    color: '#FF6B35',
    features: [
      'Unlimited AI recipes',
      'Full nutrition breakdown',
      'All 5 cuisine types',
      'Budget meals under $5 mode',
      'Save and export recipes',
      'Priority email support',
    ],
    cta: 'Start 7-Day Free Trial',
    highlight: true,
  },
  {
    name: 'Family',
    price: '$14.99',
    period: '/month',
    color: '#A78BFA',
    features: [
      'Everything in Chef plan',
      'Up to 5 family profiles',
      'Weekly meal plan generator',
      'Smart shopping list',
      'Dietary restriction filters',
      'Dedicated phone support',
    ],
    cta: 'Start Family Plan',
    highlight: false,
  },
]

export function primaryBtn(extra) {
  return {
    background: 'linear-gradient(135deg, #FF6B35, #FF9A5C)',
    color: '#fff',
    border: 'none',
    borderRadius: '12px',
    padding: '10px 20px',
    fontWeight: 600,
    fontSize: '14px',
    cursor: 'pointer',
    boxShadow: '0 4px 15px rgba(255,107,53,0.35)',
    fontFamily: "'DM Sans', sans-serif",
    ...extra,
  }
}

export function ghostBtn(extra) {
  return {
    background: 'rgba(255,107,53,0.1)',
    color: '#FF6B35',
    border: '1px solid rgba(255,107,53,0.3)',
    borderRadius: '12px',
    padding: '10px 20px',
    fontWeight: 600,
    fontSize: '14px',
    cursor: 'pointer',
    fontFamily: "'DM Sans', sans-serif",
    ...extra,
  }
}
