// Vercel Serverless Function — keeps Anthropic API key on the server
// Add ANTHROPIC_API_KEY (without VITE_ prefix) to Vercel Environment Variables
// Then change the fetch URL in src/lib/anthropic.js to '/api/generate-recipes'

export const config = { runtime: 'edge' }

export default async function handler(req) {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  }

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: corsHeaders })
  }

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  const { ingredients, cuisine, budgetMode } = await req.json()

  if (!Array.isArray(ingredients) || ingredients.length < 2) {
    return new Response(JSON.stringify({ error: 'At least 2 ingredients required' }), {
      status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  const budgetNote = budgetMode
    ? ' All meals MUST cost under $5 total. Prioritize cheap pantry staples.'
    : ''

  const prompt = `You are FeastAI, a world-class chef. Given these ingredients: ${ingredients.join(', ')}, generate 3 ${cuisine} recipes.${budgetNote}
Respond ONLY with valid JSON, no markdown:
{"recipes":[{"name":"...","emoji":"🍛","description":"...","time":"25 mins","difficulty":"Easy","servings":2,"estimatedCost":"$3.50","calories":420,"protein":28,"carbs":45,"fat":12,"ingredients":["..."],"steps":["..."],"tip":"..."}]}`

  try {
    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 2000,
        messages: [{ role: 'user', content: prompt }],
      }),
    })

    const data = await upstream.json()
    const text = data.content.map(b => b.text || '').join('')
    const clean = text.replace(/```json|```/g, '').trim()
    const parsed = JSON.parse(clean)

    return new Response(JSON.stringify(parsed), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message || 'Failed to generate recipes' }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
}
